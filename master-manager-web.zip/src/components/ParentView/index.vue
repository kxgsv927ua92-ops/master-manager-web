<template>
  <router-view />
</template>
